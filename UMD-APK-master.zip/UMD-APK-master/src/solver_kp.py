import os
import utils_apk
import defs_apk


def solve(solver_path, domain_file_name, problem_file_name, planner_type,index, consider_intermediate_plan= True):

    solution_file_path = os.path.join(defs_apk.GEN_FOLDER,'kp_output_%d.txt'%index)
    #cmd = ' %s/k-replanner %s %s --planner-path  %s --keep-intermediate-files --tmpfile-path %s > %s '%(solver_path, domain_file_name, problem_file_name,planner_path,defs.GEN_FOLDER,solution_file_path)
    #cmd = ' %s/k-replanner %s %s --planner-path  %s  --tmpfile-path %s > %s ' % (solver_path, domain_file_name, problem_file_name, planner_path, defs.GEN_FOLDER, solution_file_path)
    #cmd = ' %s/k-replanner %s %s --planner-path  %s   --keep-intermediate-files --tmpfile-path %s > %s ' %(solver_path, domain_file_name, problem_file_name, planner_path, defs.GEN_FOLDER, solution_file_path)
    #cmd = ' %s/k-replanner %s %s --planner-path  %s  --tmpfile-path %s > %s ' % ( solver_path, domain_file_name, problem_file_name, planner_path, defs.GEN_FOLDER, solution_file_path)

    if defs_apk.FF.lower() in planner_type.lower():
        planner_path = defs_apk.FF_PATH;
        #cmd = ' %s/k-replanner %s %s --planner-path  %s --options=solver:print:steps,solver:print:assumptions,solver:print:fired-sensors,planner:print:plan,planner:print:plan:raw --tmpfile-path %s --keep-intermediate-files > %s ' %(solver_path, domain_file_name, problem_file_name, planner_path, defs_apk.GEN_FOLDER, solution_file_path)
        cmd = ' %s/k-replanner %s %s --planner-path  %s --options=solver:print:steps,solver:print:assumptions,solver:print:fired-sensors,planner:print:plan,planner:print:plan:raw --tmpfile-path %s --keep-intermediate-files > %s ' % ( solver_path, domain_file_name, problem_file_name, planner_path, defs_apk.GEN_FOLDER, solution_file_path)
    elif defs_apk.FD.lower() in planner_type.lower():
        planner_path = defs_apk.FD_PATH;
        #./k-eplanner domain.pddl problem_1.pddl --keep-intermediate-files--planner -path / home / sarah / Documents / gitrepos / UtilityMaximizingDesign / solvers / Fast - Downward - -options = solver:print: assumptions, solver: print:steps, kp: print:raw, kp: print:preprocessed - -planner fd
        cmd = ' %s/k-replanner %s %s --planner-path  %s --keep-intermediate-files --options=solver:print:steps,solver:print:assumptions,solver:print:fired-sensors,planner:print:plan,planner:print:plan:raw --tmpfile-path %s  --planner fd > %s ' %(solver_path, domain_file_name, problem_file_name, planner_path, defs_apk.GEN_FOLDER, solution_file_path)

    print('cmd:')
    print(cmd)
    print('cwd')
    print(os.getcwd())

    utils_apk.run(cmd, solver_path)

    if (consider_intermediate_plan):
        plan = read_plan_with_intermediate_steps(solution_file_path)
    else:
        plan = read_succesul_plan(solution_file_path)

    return plan

def get_compiled_files(solver_path, domain_file_name, problem_file_name, planner_type,index, get_original_init = True):

    planner_path = defs_apk.get_planner_path(planner_type)

    solution_file_path = os.path.join(defs_apk.GEN_FOLDER, 'kp_output_%d.txt' % index)
    cmd = ' %s/k-replanner %s %s --planner-path  %s --keep-intermediate-files --options=solver:print:steps,solver:print:assumptions,solver:print:fired-sensors,planner:print:plan,planner:print:plan:raw,kp:print:raw --tmpfile-path %s --planner %s> %s ' % (
    solver_path, domain_file_name, problem_file_name, planner_path, defs_apk.GEN_FOLDER, planner_type,solution_file_path)

    print('cmd:')
    print(cmd)
    print('cwd')
    print(os.getcwd())

    utils_apk.run(cmd, solver_path)

    # Find the generated files and change their names
    parsed_domain_file_name = 'parsed_domain_%d.pddl' % index
    parsed_problem_file_name = 'parsed_problem_%d.pddl'%index

    # find a files with the gen-d*.pddl and gen-p*.pddl and change their names
    file_pattern = 'gen-d'
    domain_file_name = None
    for file in os.listdir(defs_apk.GEN_FOLDER):
        if file.startswith(file_pattern):
            domain_file_name = file
            os.rename(os.path.join(defs_apk.GEN_FOLDER,domain_file_name),os.path.join(defs_apk.GEN_FOLDER,parsed_domain_file_name))
            break


    file_pattern = 'gen-p'
    problem_file_name = None
    for file in os.listdir(defs_apk.GEN_FOLDER):
        if file.startswith(file_pattern):
            problem_file_name = file
            os.rename(os.path.join(defs_apk.GEN_FOLDER,problem_file_name),os.path.join(defs_apk.GEN_FOLDER,parsed_problem_file_name))
            break
    if get_original_init:
        original_init = read_original_initial_state(solution_file_path)

        print('original_init')
        print(original_init)
        #inject the init into the parsed_problem_file_name file
        parsed_problem_file = open(os.path.join(defs_apk.GEN_FOLDER,parsed_problem_file_name), "r")
        lines = parsed_problem_file.readlines()
        parsed_problem_file.close()

        new_file_lines = []
        for line in lines:
            if '(:init' in line:
                init_line = '(:init'
                if defs_apk.FD in planner_type:
                    init_line += '(= (total-cost) 0)\n'

                init_line+=original_init
                init_line += ')\n'
                new_file_lines.append(init_line)
            else:
                new_file_lines.append(line)
        parsed_problem_file = open(os.path.join(defs_apk.GEN_FOLDER, parsed_problem_file_name), "w")
        parsed_problem_file.writelines(new_file_lines)
        parsed_problem_file.close()
        print(new_file_lines)

    return [os.path.join(defs_apk.GEN_FOLDER,parsed_domain_file_name),os.path.join(defs_apk.GEN_FOLDER,parsed_problem_file_name)]

def read_original_initial_state(solution_file_path):
    # open solution path and read lines
    solution_file = open(solution_file_path, "r")
    lines = solution_file.readlines()
    index = 0
    while index < len(lines):
        #read the initial state
        if '>>> initial state={' in lines[index]:
            init_state = lines[index]
            init_state = init_state.replace('>>> initial state={','')
            init_state = init_state.replace('}', '')
            return init_state
        else:
            index +=1



def read_plan_with_intermediate_steps(solution_file_path):

    # open solution path and read lines
    solution_file = open(solution_file_path, "r")
    lines = solution_file.readlines()
    plan = []
    reading_plan = False
    has_solution = True
    for line in lines:
        if 'unable to solve problem' in line:
            has_solution = False
            plan.append(defs_apk.FAILURE_STRING)
            break

        if 'kp-action=' in line:
            action = line.split()[1]
            action = action.split('=')[1]
            plan.append(action)

    return plan

def read_succesul_plan(solution_file_path):

    # open solution path and read lines
    solution_file = open(solution_file_path, "r")
    lines = solution_file.readlines()
    plan = []
    reading_plan = False
    has_solution = True
    for line in lines:
        #start reading the plan
        if 'PLAN:' in line:
            line = line.replace('PLAN:','')
            reading_plan = True
        if 'stats:' in line:
            break
        if 'problem has no solution!' in line:
            has_solution = False
            break
        if reading_plan:
            action = line.split(':')[1]
            action = action.replace('\n','')
            plan.append(action)

    if has_solution:
        print('plan is %s'%plan)
        return plan
    else:
        print('there is no solution')
        return None


def kp_solve():

    import shutil
    import sys
    import os

    # clean the gen folder
    #if os.path.exists(defs_apk.GEN_FOLDER):
    #    shutil.rmtree(defs_apk.GEN_FOLDER)
    #os.makedirs(defs_apk.GEN_FOLDER)

    # parse input
    solver_path = sys.argv[1]# e.g. '/mnt/c/Users/sarah/OneDrive/Documents/UtilityMaximizingDesign/solvers/PRP/planner-for-relevant-policies/src'
    solver_path = os.path.abspath(solver_path)
    domain_file_name = os.path.abspath(sys.argv[2])# e.g. '/mnt/c/Users/sarah/OneDrive/Documents/UtilityMaximizingDesign/benchmarks/grd-apo/pond-benchmarks-sarah/wumpus-clg/wumpus-running-example-grd/wumpus05/d.pddl'
    template_file_name = os.path.abspath(sys.argv[3])#e,g, '/mnt/c/Users/sarah/OneDrive/Documents/UtilityMaximizingDesign/benchmarks/grd-apo/pond-benchmarks-sarah/wumpus-clg/wumpus-running-example-grd/wumpus05/template.pddl'
    hyps_file_name = os.path.abspath(sys.argv[4])# e.g. '/mnt/c/Users/sarah/OneDrive/Documents/UtilityMaximizingDesign/benchmarks/grd-apo/pond-benchmarks-sarah/wumpus-clg/wumpus-running-example-grd/wumpus05/hyps.dat'

    cwd = os.getcwd()
    print('cwd')
    print(cwd)
    print('\n\nsolver path')
    print(solver_path)

    # generate problem files
    [hyps, problem_files] = utils.generate_problem_files(template_file_name, hyps_file_name)
    planner_path = os.path.abspath('./solvers/FF-v2.3')
    plan = solve(solver_path, domain_file_name, problem_files[0], planner_path, 0)
    print('plan is: ')
    print(plan)

    plan = solve(solver_path, domain_file_name, problem_files[1], planner_path, 1)
    print('plan is: ')
    print(plan)

if __name__ == '__main__':
    kp_solve()