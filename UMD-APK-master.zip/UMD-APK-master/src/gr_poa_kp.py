__author__ = 'sarah'

import gr
import utils_apk, defs_apk, solver_kp
import os, sys
import copy
import modification_apk



class GR_POA_KP(gr.GR):

    """Goal Recognition superclass
       supporting COMPLETE
    """
    def __init__(self, solver_path, domain_file_name, template_file_name, hyps_file_name,planner_type):

        super().__init__()

        # the decision making mechanism of the agent
        self.solver_path = os.path.abspath(solver_path)

        # the 3 files that represent the goal recognition setting
        self.domain_file_name = os.path.abspath(domain_file_name)
        self.template_file_name = os.path.abspath(template_file_name)
        self.hyps_file_name = os.path.abspath(hyps_file_name)

        # parse the template file to find recognizer's knowldedge
        self.rec_knowledge = self.process_knowledge(self.template_file_name)

        self.planner_type = planner_type

    # create a modified model according to the modification
    def create_modified_model(self, modified_element, modified_file):

        solver_path = self.solver_path
        domain_file_name = self.domain_file_name
        template_file_name = self.template_file_name
        hyps_file_name = self.hyps_file_name


        if defs_apk.TEMPLATE_FILE in modified_element:
            template_file_name = modified_file

        elif defs_apk.DOMAIN_FILE in modified_element:
            domain_file_name = modified_file

        elif defs_apk.HYPS_FILE in modified_element:
            hyps_file_name = modified_file

        modified_model = GR_POA_KP(solver_path,domain_file_name,template_file_name,hyps_file_name,self.planner_type)
        return modified_model

    '''
        Parse the template file to get all the knowledge items of the recognition system
    '''
    def process_knowledge(self, template_file_name):

        if not os.path.exists(template_file_name):
            print('Error in process_rec_knowledge : File %s does not exist' % template_file_name)
            return None

        # open file and read it
        template_file = open(template_file_name, "r")
        template_file_lines = template_file.readlines()
        template_file.close()

        # read all lines from the template file and copy them to the problem file, except for the <hyp> line which is replaced by hyp
        rec_knowledge = []
        lines_count = len(template_file_lines)
        index = 0
        while index < lines_count:
            line = template_file_lines[index]
            if 'hidden' in line:
                index = index + 1
                line = template_file_lines[index]
                while ';; end_hidden' not in line:
                    line_info = line[line.find("(") - 1 + 1:line.find(")") + 1]
                    line_info = line_info.replace(')', '')
                    line_info = line_info.replace('(', '')
                    rec_knowledge.append(line_info)
                    index = index + 1
                    line = template_file_lines[index]
                break

            index += 1

        #print('rec and agent knowledge')
        #print(rec_knowledge)

        return rec_knowledge

    '''
        get the policy graph of the hyps in the set by invoking the PRP planner
    '''
    def get_policiy_graphs(self, hyps_set_calc, problem_files):

        policy_graphs = []

        for hyp_index in hyps_set_calc:

            cur_problem_file = problem_files[hyp_index]
            plan = solver_kp.solve(self.solver_path, self.domain_file_name, cur_problem_file, self.planner_type, hyp_index)
            policy_graphs.append(plan)


        return policy_graphs

    def get_problem_files(self):

        # generate problem files
        [self.hyps, problem_files] = utils_apk.generate_problem_files(self.template_file_name, self.hyps_file_name)
        return problem_files

    def get_compiled_files(self):

        # generate problem files
        [self.hyps, problem_files] = utils_apk.generate_problem_files(self.template_file_name, self.hyps_file_name)

        hyp_index = 0
        compiled_files = []
        for cur_problem_file in problem_files:
            [compiled_domain, compiled_problem] = solver_kp.get_compiled_files(self.solver_path, self.domain_file_name, cur_problem_file, self.planner_type, hyp_index)
            compiled_files.append([compiled_domain,compiled_problem])
            hyp_index += 1

        return compiled_files

    # find the wcd of the current node
    # hyps_indices - soecifies the specific indices to consider
    # cleanup - should files be delted after calculation
    def get_wcd(self, hyps_indices=None):


        # generate problem files
        [self.hyps, problem_files] = utils_apk.generate_problem_files(self.template_file_name, self.hyps_file_name)

        # make sure the problem files are unique to each node by changing their name
        #self.problem_files = []
        #for file in problem_files:
        #    temp_file = os.path.splitext(os.path.basename(self.template_file_name))[0]
        #    temp_file = temp_file.replace('template','')
        #    mod_name = '%s--%s.pddl' % (file,temp_file)
        #    os.rename(file, mod_name)
        #    self.problem_files.append(mod_name)


        # get the list of hyps
        hyps_set_calc = hyps_indices
        if hyps_indices is None:
            hyps_set_calc  = list(range(0,len(self.hyps)))

        # calculate the policy for each hyp
        self.policy_graphs = self.get_policiy_graphs(hyps_set_calc,problem_files)

        # find all pairs
        all_pairs = utils_apk.get_all_pairs(hyps_set_calc, False)

        # find the maximal common trajectory between all pairs of policies
        max_wcd_all_pairs = []
        wcd = -1
        wcd_pair = None
        for pair in all_pairs:
            graph_0 = self.policy_graphs[pair[0]]
            graph_1 = self.policy_graphs[pair[1]]
            if graph_0 is None or graph_1 is None:
                cur_wcd_node = None
                cur_wcd = -1
                max_wcd_all_pairs.append([pair, cur_wcd_node, cur_wcd])
            else:
                # get the common prefix (not considering failure steps - where the agents decides to abort execution)
                [cur_wcd_node, cur_wcd] = utils_apk.get_maximal_common_prefix_lists(graph_0,graph_1,False)
                max_wcd_all_pairs.append([pair, cur_wcd_node, cur_wcd])
            if cur_wcd > wcd :
                wcd_pair = pair
                wcd = cur_wcd


        return [wcd, wcd_pair,max_wcd_all_pairs]

    def recognize(self, observation):
        # COMPLETE
        return None

    def is_valid(self, cur_modification):

        #if this is an iformationshaping modificaiton, we need to make sure the information is consistent with the true state
        if modification_apk.InformationShapingModification.__name__ in cur_modification.__class__.__name__:

            if cur_modification.neg_predicate is not None:
                pred = cur_modification.neg_predicate.replace(')', '')
                pred = pred.replace('(', '')

                # conveying false negative information
                if pred in self.rec_knowledge:
                    return False

            if cur_modification.predicate is not None:
                pred = cur_modification.predicate.replace(')', '')
                pred = pred.replace('(', '')

                # conveying false positive information
                if pred not in self.rec_knowledge:
                    return False

        return True

    def clean_up(self):
        # TODO SARAH: this is a temp solution, make cleanup cleaner
        if defs_apk.GEN_FOLDER in self.template_file_name:
            os.remove(self.template_file_name)




def calc_wcd():

    import shutil
    # clean the gen folder
    if os.path.exists(defs_apk.GEN_FOLDER):
        shutil.rmtree(defs_apk.GEN_FOLDER)
    os.makedirs(defs_apk.GEN_FOLDER)

    # parse input
    solver_path = sys.argv[1]# e.g. '/mnt/c/Users/sarah/OneDrive/Documents/UtilityMaximizingDesign/solvers/PRP/planner-for-relevant-policies/src'
    domain_file_name = sys.argv[2]# e.g. '/mnt/c/Users/sarah/OneDrive/Documents/UtilityMaximizingDesign/benchmarks/grd-apo/pond-benchmarks-sarah/wumpus-clg/wumpus-running-example-grd/wumpus05/d.pddl'
    template_file_name = sys.argv[3]#e,g, '/mnt/c/Users/sarah/OneDrive/Documents/UtilityMaximizingDesign/benchmarks/grd-apo/pond-benchmarks-sarah/wumpus-clg/wumpus-running-example-grd/wumpus05/template.pddl'
    hyps_file_name = sys.argv[4]# e.g. '/mnt/c/Users/sarah/OneDrive/Documents/UtilityMaximizingDesign/benchmarks/grd-apo/pond-benchmarks-sarah/wumpus-clg/wumpus-running-example-grd/wumpus05/hyps.dat'


    # create the goal recognition problem
    gr_poa_problem = GR_POA_KP(solver_path, domain_file_name, template_file_name, hyps_file_name)


    # get the wcd
    [wcd, wcd_pair, max_wcd_all_pairs] = gr_poa_problem.get_wcd()
    print('wcd is %d'%wcd)



if __name__ == '__main__':
    #test_wcd()
    #test_modifications()
    calc_wcd()







