__author__ = 'sarah'

from UMD import heuristic
import causal_graph


def get_heuristic(heuristic_name, umd_problem):
    if 'cg-unique' in heuristic_name:
        return cg_unique_heuristic
    else:
        return heuristic.get_heuristic(heuristic_name, umd_problem)


def cg_unique_heuristic(design_node):

    if design_node.umd_problem.causal_graphs is None:
        print('before getting Causal Graph')
        design_node.umd_problem.causal_graphs = causal_graph.get_causal_graphs_from_compilation(design_node.umd_problem)
        print('after getting Causal Graph')

    #COMPLETE !

