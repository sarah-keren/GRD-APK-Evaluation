# UMD-APK
UMD for agents with partial knowledge


./scripts/grd_design_experiments ./solvers/cp2fsc-and-replanner-prudent/src ./benchmarks/dataset/wumpus

